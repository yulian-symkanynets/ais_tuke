"""
Main entry point for AIS-TUKE AI Agents System
Runs autonomous agents overnight to develop the academic information system
"""
import os
from datetime import datetime, timedelta
from agents.orchestrator_agent import OrchestratorAgent
from memory.context_manager import ContextManager

def setup_workspace():
    """Ensure workspace and memory directories exist"""
    os.makedirs("workspace", exist_ok=True)
    os.makedirs("memory", exist_ok=True)
    os.makedirs("workspace/backend", exist_ok=True)
    os.makedirs("workspace/frontend", exist_ok=True)
    os.makedirs("workspace/tests", exist_ok=True)

def main():
    print("🚀 Starting AIS-TUKE AI Agents System")
    print(f"⏰ Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    setup_workspace()
    
    # Initialize context manager for memory
    context_manager = ContextManager()
    
    # Initialize orchestrator agent
    orchestrator = OrchestratorAgent(context_manager)
    
    # Define the main goal
    initial_task = """
    Develop a complete Academic Information System (AIS) similar to MAIS TUKE with:
    1. Backend API (FastAPI) with authentication, courses, students, grades
    2. Frontend (React/Vite) with student dashboard, course enrollment, grade viewing
    3. Database models and migrations
    4. Authentication and authorization
    5. Comprehensive tests for all features
    
    Work incrementally, test after each feature, and maintain clean code.
    """
    
    # Run for 8 hours (or adjust as needed)
    end_time = datetime.now() + timedelta(hours=8)
    iteration = 0
    
    try:
        while datetime.now() < end_time:
            iteration += 1
            print(f"\n{'='*60}")
            print(f"🔄 Iteration {iteration} - {datetime.now().strftime('%H:%M:%S')}")
            print(f"{'='*60}\n")
            
            # Orchestrator plans and executes
            result = orchestrator.execute(initial_task if iteration == 1 else None)
            
            # Save progress to memory
            context_manager.save_iteration(iteration, result)
            
            print(f"\n✅ Iteration {iteration} complete")
            print(f"📊 Result: {result.get('summary', 'No summary')}\n")
            
            # Check if goal is complete
            if result.get('status') == 'complete':
                print("🎉 All tasks completed successfully!")
                break
                
    except KeyboardInterrupt:
        print("\n\n⚠️ Interrupted by user")
    except Exception as e:
        print(f"\n\n❌ Error: {e}")
        context_manager.save_error(iteration, str(e))
    finally:
        print(f"\n⏰ Ended at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("💾 All progress saved to memory/")

if __name__ == "__main__":
    main()