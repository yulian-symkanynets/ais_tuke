"""
Orchestrator Agent - Plans and delegates tasks to specialized agents
"""
from strands import Agent
from strands.models.ollama import OllamaModel
from agents.backend_dev_agent import BackendDevAgent
from agents.frontend_dev_agent import FrontendDevAgent
from agents.tester_agent import TesterAgent
from agents.tools.filesystem_tools import read_file, write_file, list_files
from agents.tools.git_tools import git_status, git_commit
from agents.tools.build_tools import run_backend_tests, run_frontend_build
import time

ollama_model = OllamaModel(
    host="http://localhost:11434",
    model_id="llama3.1"
)

class OrchestratorAgent:
    def __init__(self, context_manager):
        self.context_manager = context_manager

        # Initialize specialized agents
        self.backend_agent = BackendDevAgent()
        self.frontend_agent = FrontendDevAgent()
        self.tester_agent = TesterAgent()

        # Main orchestrator model
        self.agent = Agent(
            name="AIS Orchestrator",
            model=ollama_model,
            system_prompt="""You are the lead architect for an Academic Information System (AIS).

Responsibilities:
1. Break work into phases and goals.
2. Delegate to Backend, Frontend, and Tester agents.
3. Ensure code is written using write_file() and committed via git_commit().
4. Maintain a clear development log in memory/plan.md.
5. After each implementation, trigger tests and collect results.
6. Never just describe what to do — issue explicit tool calls.

Current project structure:
- backend/ : FastAPI application
- src/ : React/Vite frontend
- memory/ : Development plans and history
- workspace/ : Generated code

Work iteratively. After each change:
- run tests (run_backend_tests / run_frontend_build)
- summarize results
- commit changes with a descriptive message.
""",
            tools=[read_file, write_file, list_files, git_status, git_commit]
        )

    # ----------------------------------------------------------------------

    def execute(self, initial_task=None):
        """Run one orchestrator iteration"""
        context = self.context_manager.load_context()

        if initial_task:
            plan_prompt = f"""
            Initial task: {initial_task}

            Create a detailed multi-phase development plan:
            Phase 1 – Backend foundation
            Phase 2 – Database + Auth
            Phase 3 – Frontend scaffold
            Phase 4 – Integration
            Phase 5 – Testing + Polish

            Save the plan to memory/plan.md using write_file().
            Identify the first actionable backend or frontend task and begin it.
            """
            response = self.agent(plan_prompt)
        else:
            progress_prompt = f"""
            Previous context: {context}

            Review progress, decide the next task, and delegate it.
            Remember: use write_file() for code creation, run tests, and commit after success.
            """
            response = self.agent(progress_prompt)

        result = self._delegate_work(response)
        return result

    # ----------------------------------------------------------------------

    def _delegate_work(self, orchestrator_response):
        """Send work to the right agent"""
        resp_text = str(orchestrator_response)
        lower = resp_text.lower()

        result = {
            "orchestrator_decision": resp_text,
            "delegated_to": None,
            "output": None,
            "status": "in_progress"
        }

        if any(k in lower for k in ["backend", "api", "fastapi"]):
            print("📡 Delegating to Backend Developer Agent…")
            result["delegated_to"] = "backend"
            result["output"] = self.backend_agent.execute(resp_text)

        elif any(k in lower for k in ["frontend", "react", "ui"]):
            print("🎨 Delegating to Frontend Developer Agent…")
            result["delegated_to"] = "frontend"
            result["output"] = self.frontend_agent.execute(resp_text)

        elif any(k in lower for k in ["test", "verify", "qa"]):
            print("🧪 Delegating to Tester Agent…")
            result["delegated_to"] = "tester"
            result["output"] = self.tester_agent.execute(resp_text)

        else:
            print("📋 Planning / documentation step…")
            result["delegated_to"] = "orchestrator"
            result["output"] = orchestrator_response

        # Run post-task actions
        self._after_task(result)
        result["summary"] = self._create_summary(result)
        return result

    # ----------------------------------------------------------------------

    def _after_task(self, result):
        """Automatically run tests and commit progress"""
        agent = result["delegated_to"]

        if agent == "backend":
            print("🧩 Running backend tests…")
            test_results = run_backend_tests()
            print(test_results)
            git_commit("backend update + tests")

        elif agent == "frontend":
            print("🧩 Building frontend…")
            build_results = run_frontend_build()
            print(build_results)
            git_commit("frontend update + build")

        elif agent == "tester":
            git_commit("QA tests and reports")

        time.sleep(1)  # tiny delay to avoid hammering file system

    # ----------------------------------------------------------------------

    def _create_summary(self, result):
        agent = result["delegated_to"]
        out = str(result["output"])[:200]
        return f"[{agent}] {out}..."
