"""
Git Tools - Version control operations for AI agents
"""
from strands import tool
import subprocess

def _run_git_command(args: list) -> tuple[bool, str]:
    """Helper to run git commands safely"""
    try:
        result = subprocess.run(
            ['git'] + args,
            capture_output=True,
            text=True,
            timeout=30
        )
        return result.returncode == 0, result.stdout + result.stderr
    except subprocess.TimeoutExpired:
        return False, "Git command timed out"
    except Exception as e:
        return False, f"Error: {str(e)}"

@tool
def git_status() -> str:
    """
    Get current git status showing modified, staged, and untracked files.
    
    Returns:
        Git status output
    """
    success, output = _run_git_command(['status', '--short'])
    
    if success:
        if not output.strip():
            return "✓ Working directory clean - no changes"
        return f"Git status:\n{output}"
    else:
        return f"Error getting git status: {output}"

@tool
def git_diff(file_path: str = "") -> str:
    """
    Show changes in working directory.
    
    Args:
        file_path: Optional specific file to diff (default: all files)
    
    Returns:
        Git diff output
    """
    args = ['diff']
    if file_path:
        args.append(file_path)
    
    success, output = _run_git_command(args)
    
    if success:
        if not output.strip():
            return "No changes to show"
        return f"Changes:\n{output}"
    else:
        return f"Error getting diff: {output}"

@tool
def git_add(files: str) -> str:
    """
    Stage files for commit.
    
    Args:
        files: Files to add (use "." for all, or specific paths)
    
    Returns:
        Success message
    """
    success, output = _run_git_command(['add', files])
    
    if success:
        return f"✓ Staged files: {files}"
    else:
        return f"Error staging files: {output}"

@tool
def git_commit(message: str) -> str:
    """
    Commit staged changes with a message.
    
    Args:
        message: Commit message describing changes
    
    Returns:
        Commit success message with hash
    """
    if not message or len(message.strip()) < 3:
        return "Error: Commit message must be at least 3 characters"
    
    success, output = _run_git_command(['commit', '-m', message])
    
    if success:
        # Extract commit hash from output
        lines = output.strip().split('\n')
        return f"✓ Committed: {lines[0] if lines else 'success'}"
    else:
        if "nothing to commit" in output.lower():
            return "Nothing to commit - no staged changes"
        return f"Error committing: {output}"

@tool
def git_log(count: int = 5) -> str:
    """
    Show recent commit history.
    
    Args:
        count: Number of recent commits to show (default: 5)
    
    Returns:
        Formatted commit log
    """
    success, output = _run_git_command([
        'log',
        f'-{count}',
        '--oneline',
        '--decorate'
    ])
    
    if success:
        if not output.strip():
            return "No commits yet"
        return f"Recent commits:\n{output}"
    else:
        return f"Error getting log: {output}"

@tool
def git_branch() -> str:
    """
    List all branches and show current branch.
    
    Returns:
        Branch list with current branch marked
    """
    success, output = _run_git_command(['branch', '-v'])
    
    if success:
        return f"Branches:\n{output}"
    else:
        return f"Error listing branches: {output}"

@tool
def git_create_branch(branch_name: str) -> str:
    """
    Create and checkout a new branch.
    
    Args:
        branch_name: Name of the new branch
    
    Returns:
        Success message
    """
    if not branch_name or not branch_name.replace('-', '').replace('_', '').isalnum():
        return "Error: Invalid branch name. Use letters, numbers, hyphens, underscores only"
    
    success, output = _run_git_command(['checkout', '-b', branch_name])
    
    if success:
        return f"✓ Created and switched to branch: {branch_name}"
    else:
        return f"Error creating branch: {output}"