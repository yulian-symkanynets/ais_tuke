"""
Filesystem Tools - Safe file operations for AI agents
"""
from strands import tool
import os
from pathlib import Path

# Define safe workspace boundaries
WORKSPACE_ROOT = Path("workspace").resolve()
BACKEND_ROOT = Path("backend").resolve()
SRC_ROOT = Path("src").resolve()

def _is_safe_path(path: str) -> bool:
    """Check if path is within safe boundaries"""
    resolved = Path(path).resolve()
    return (
        resolved.is_relative_to(WORKSPACE_ROOT) or
        resolved.is_relative_to(BACKEND_ROOT) or
        resolved.is_relative_to(SRC_ROOT)
    )

@tool
def read_file(path: str) -> str:
    """
    Read content from a file.
    
    Args:
        path: File path to read (relative to project root)
    
    Returns:
        File content as string
    """
    if not _is_safe_path(path):
        return f"Error: Access denied to {path}. Must be in workspace/, backend/, or src/"
    
    try:
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()
        return f"✓ Read {len(content)} characters from {path}\n\n{content}"
    except FileNotFoundError:
        return f"Error: File {path} not found"
    except Exception as e:
        return f"Error reading {path}: {str(e)}"

@tool
def write_file(path: str, content: str) -> str:
    """
    Write content to a file, creating directories if needed.
    
    Args:
        path: File path to write (relative to project root)
        content: Content to write to file
    
    Returns:
        Success message
    """
    print(f"[AI WRITE] {path}")
    if not _is_safe_path(path):
        return f"Error: Access denied to {path}. Must be in workspace/, backend/, or src/"
    
    try:
        # Create parent directories if they don't exist
        os.makedirs(os.path.dirname(path), exist_ok=True)
        
        with open(path, 'w', encoding='utf-8') as f:
            f.write(content)
        
        return f"✓ Wrote {len(content)} characters to {path}"
    except Exception as e:
        return f"Error writing {path}: {str(e)}"

@tool
def list_files(directory: str = ".", pattern: str = "*") -> str:
    """
    List files in a directory.
    
    Args:
        directory: Directory to list (relative to project root)
        pattern: Glob pattern to filter files (default: *)
    
    Returns:
        List of files found
    """
    if not _is_safe_path(directory):
        return f"Error: Access denied to {directory}"
    
    try:
        path = Path(directory)
        if not path.exists():
            return f"Error: Directory {directory} does not exist"
        
        files = sorted(path.glob(pattern))
        
        if not files:
            return f"No files matching '{pattern}' in {directory}"
        
        result = [f"Files in {directory}:"]
        for f in files:
            if f.is_file():
                size = f.stat().st_size
                result.append(f"  📄 {f.name} ({size} bytes)")
            elif f.is_dir():
                result.append(f"  📁 {f.name}/")
        
        return "\n".join(result)
    except Exception as e:
        return f"Error listing {directory}: {str(e)}"

@tool
def create_directory(path: str) -> str:
    """
    Create a directory (and parent directories if needed).
    
    Args:
        path: Directory path to create
    
    Returns:
        Success message
    """
    if not _is_safe_path(path):
        return f"Error: Access denied to {path}"
    
    try:
        os.makedirs(path, exist_ok=True)
        return f"✓ Created directory {path}"
    except Exception as e:
        return f"Error creating directory {path}: {str(e)}"

@tool
def delete_file(path: str) -> str:
    """
    Delete a file.
    
    Args:
        path: File path to delete
    
    Returns:
        Success message
    """
    if not _is_safe_path(path):
        return f"Error: Access denied to {path}"
    
    try:
        if os.path.exists(path):
            os.remove(path)
            return f"✓ Deleted {path}"
        else:
            return f"Error: File {path} does not exist"
    except Exception as e:
        return f"Error deleting {path}: {str(e)}"