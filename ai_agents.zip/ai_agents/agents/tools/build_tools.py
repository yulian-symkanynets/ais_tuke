"""
Build Tools - Run commands, tests, and builds for AI agents
"""
from strands import tool
import subprocess
import os

def _run_command_safe(command: str, cwd: str = ".", timeout: int = 120) -> tuple[bool, str]:
    """Helper to run shell commands safely"""
    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            cwd=cwd,
            timeout=timeout
        )
        return result.returncode == 0, result.stdout + result.stderr
    except subprocess.TimeoutExpired:
        return False, f"Command timed out after {timeout}s"
    except Exception as e:
        return False, f"Error: {str(e)}"

@tool
def run_command(command: str, working_dir: str = ".") -> str:
    """
    Run a shell command in a specific directory.
    
    Args:
        command: Shell command to execute
        working_dir: Working directory (default: current)
    
    Returns:
        Command output and exit status
    """
    # Block dangerous commands
    dangerous = ['rm -rf', 'dd ', 'mkfs', ':(){:|:&};:', 'fork bomb']
    if any(d in command.lower() for d in dangerous):
        return f"Error: Dangerous command blocked: {command}"
    
    success, output = _run_command_safe(command, cwd=working_dir)
    
    status = "✓" if success else "✗"
    return f"{status} Command: {command}\nOutput:\n{output}"

@tool
def run_backend_tests(test_path: str = "") -> str:
    """
    Run backend tests using pytest.
    
    Args:
        test_path: Specific test file or directory (default: all tests)
    
    Returns:
        Test results
    """
    if not os.path.exists("backend"):
        return "Error: backend/ directory not found"
    
    command = "pytest"
    if test_path:
        command += f" {test_path}"
    command += " -v --tb=short"
    
    success, output = _run_command_safe(command, cwd="backend", timeout=180)
    
    status = "✓ Tests passed" if success else "✗ Tests failed"
    return f"{status}\n\n{output}"

@tool
def run_frontend_build() -> str:
    """
    Build the frontend application using Vite.
    
    Returns:
        Build output
    """
    if not os.path.exists("src"):
        return "Error: src/ directory not found"
    
    success, output = _run_command_safe("npm run build", cwd=".", timeout=180)
    
    status = "✓ Build successful" if success else "✗ Build failed"
    return f"{status}\n\n{output}"

@tool
def run_frontend_tests() -> str:
    """
    Run frontend tests using Vitest.
    
    Returns:
        Test results
    """
    success, output = _run_command_safe("npm run test", cwd=".", timeout=180)
    
    status = "✓ Tests passed" if success else "✗ Tests failed"
    return f"{status}\n\n{output}"

@tool
def install_dependencies(package_manager: str = "pip", package: str = "") -> str:
    """
    Install project dependencies.
    
    Args:
        package_manager: "pip" for Python or "npm" for Node.js
        package: Specific package to install (optional)
    
    Returns:
        Installation output
    """
    if package_manager == "pip":
        if package:
            command = f"pip install {package}"
        else:
            command = "pip install -r requirements.txt"
        cwd = "backend"
    elif package_manager == "npm":
        if package:
            command = f"npm install {package}"
        else:
            command = "npm install"
        cwd = "."
    else:
        return f"Error: Unknown package manager: {package_manager}"
    
    if not os.path.exists(cwd):
        return f"Error: {cwd}/ directory not found"
    
    success, output = _run_command_safe(command, cwd=cwd, timeout=300)
    
    status = "✓ Installation complete" if success else "✗ Installation failed"
    return f"{status}\n\n{output}"

@tool
def check_python_syntax(file_path: str) -> str:
    """
    Check Python file for syntax errors.
    
    Args:
        file_path: Path to Python file to check
    
    Returns:
        Syntax check results
    """
    if not file_path.endswith('.py'):
        return "Error: File must be a .py file"
    
    if not os.path.exists(file_path):
        return f"Error: File {file_path} not found"
    
    success, output = _run_command_safe(f"python -m py_compile {file_path}")
    
    if success:
        return f"✓ {file_path} - No syntax errors"
    else:
        return f"✗ Syntax errors in {file_path}:\n{output}"

@tool
def run_linter(file_path: str = ".", tool: str = "flake8") -> str:
    """
    Run code linter to check code quality.
    
    Args:
        file_path: File or directory to lint
        tool: Linter to use (flake8, pylint, eslint)
    
    Returns:
        Linting results
    """
    if tool == "flake8":
        command = f"flake8 {file_path} --max-line-length=100"
    elif tool == "pylint":
        command = f"pylint {file_path}"
    elif tool == "eslint":
        command = f"npx eslint {file_path}"
    else:
        return f"Error: Unknown linter: {tool}"
    
    success, output = _run_command_safe(command)
    
    if success or "no issues found" in output.lower():
        return f"✓ Linting passed\n{output}"
    else:
        return f"⚠ Linting issues found:\n{output}"