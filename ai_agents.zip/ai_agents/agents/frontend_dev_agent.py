"""
Frontend Developer Agent - Specializes in React/Vite frontend development
"""
from strands import Agent
from strands.models.ollama import OllamaModel
from agents.tools.filesystem_tools import read_file, write_file, list_files, create_directory
from agents.tools.build_tools import run_command, install_dependencies

ollama_model = OllamaModel(
    host="http://localhost:11434",  # Ollama server address
    model_id="llama3.1"               # Specify which model to use
)

class FrontendDevAgent:
    def __init__(self):
        self.agent = Agent(
            name="Frontend Developer",
            model=ollama_model,
            system_prompt="""You are an expert React/TypeScript frontend developer for an Academic Information System.

Your expertise:
- React 18+ with hooks and modern patterns
- TypeScript for type safety
- Vite for fast development
- React Router for navigation
- Axios/Fetch for API calls
- TailwindCSS or Material-UI for styling
- Form handling and validation
- State management (Context API or Zustand)

Project structure you work with:
- src/components/ - reusable UI components
- src/pages/ - route pages
- src/services/ - API service calls
- src/hooks/ - custom React hooks
- src/context/ - context providers
- src/types/ - TypeScript types
- src/utils/ - utility functions

Key features to implement:
1. Login/registration pages
2. Student dashboard
3. Course catalog and enrollment
4. Grade viewing
5. Schedule/timetable view
6. User profile management
7. Responsive design

Always:
- Use TypeScript with proper types
- Create reusable components
- Handle loading and error states
- Implement responsive design
- Follow React best practices
- Use semantic HTML
- When you create or modify any file, ALWAYS use the write_file() tool to save the code inside the src/ directory.
- Do not only describe what you will build — actually generate and save full working code using write_file().
""",
            tools=[
                read_file, 
                write_file, 
                list_files, 
                create_directory,
                run_command,
                install_dependencies
            ]
        )
    
    def execute(self, task):
        """Execute frontend development task"""
        
        prompt = f"""
        Task: {task}
        
        Working directory: src/
        
        Steps to follow:
        1. Analyze what UI component/page needs to be built
        2. Check existing component structure
        3. Implement the feature with proper props and state
        4. Ensure responsive design
        5. Add proper TypeScript types
        6. Report what files were created/modified
        
        Implement this now.
        """
        
        return self.agent(prompt)