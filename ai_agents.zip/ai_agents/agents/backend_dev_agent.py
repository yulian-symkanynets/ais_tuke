"""
Backend Developer Agent - Specializes in FastAPI backend development
"""
from strands import Agent
from strands.models.ollama import OllamaModel

from agents.tools.filesystem_tools import read_file, write_file, list_files, create_directory
from agents.tools.build_tools import run_command, install_dependencies

ollama_model = OllamaModel(
    host="http://localhost:11434",  # Ollama server address
    model_id="llama3.1"               # Specify which model to use
)


class BackendDevAgent:
    def __init__(self):
        self.agent = Agent(
            name="Backend Developer",
            model=ollama_model,
            system_prompt="""You are an expert FastAPI backend developer for an Academic Information System.

Your expertise:
- FastAPI applications with proper routing and middleware
- SQLAlchemy models and database migrations
- JWT authentication and authorization
- RESTful API design
- Python best practices and type hints
- pytest for testing

Project structure you work with:
- backend/app/ - main application code
- backend/app/models/ - database models
- backend/app/routers/ - API endpoints
- backend/app/core/ - config, security, database
- backend/tests/ - test files

Key features to implement:
1. User authentication (students, teachers, admins)
2. Course management (CRUD operations)
3. Student enrollment system
4. Grade management
5. Schedule/timetable system
6. Database models with proper relationships

Always:
- Write type-annotated code
- Include docstrings
- Follow FastAPI best practices
- Create accompanying tests
- Use environment variables for configuration

**When you create or modify any file, ALWAYS use the write_file() tool to save the code in the appropriate backend/ folder. Do not just describe what you will do — actually write the code using the tools available.**
""",
            tools=[
                read_file, 
                write_file, 
                list_files, 
                create_directory,
                run_command,
                install_dependencies
            ]
        )
    
    def execute(self, task):
        """Execute backend development task"""
        
        prompt = f"""
        Task: {task}
        
        Working directory: backend/
        
        Steps to follow:
        1. Analyze what needs to be built
        2. Check existing code structure
        3. Implement the feature with proper error handling
        4. Write clean, maintainable code
        5. Report what files were created/modified
        
        Implement this now.
        """
        
        return self.agent(prompt)