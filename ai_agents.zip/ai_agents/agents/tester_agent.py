"""
Tester Agent - Specializes in testing and quality assurance
"""
from strands import Agent
from strands.models.ollama import OllamaModel
from agents.tools.filesystem_tools import read_file, write_file, list_files
from agents.tools.build_tools import run_backend_tests, run_frontend_build, run_command
ollama_model=OllamaModel(
                host="http://localhost:11434",  # Ollama server address
                model_id="llama3.1"               # Specify which model to use
            ),
class TesterAgent:
    def __init__(self):
        self.agent = Agent(
            name="QA Tester",
            model=ollama_model,
            system_prompt="""You are an expert QA engineer specializing in automated testing.

Your expertise:
- pytest for Python backend testing
- Jest/Vitest for frontend testing
- Integration testing
- API endpoint testing
- Unit testing best practices
- Test coverage analysis
- Bug identification and reporting

Testing strategy:
1. Unit tests for individual functions/components
2. Integration tests for API endpoints
3. End-to-end tests for critical flows
4. Edge case and error handling tests

For Backend (pytest):
- Test all API endpoints
- Test authentication and authorization
- Test database operations
- Test input validation
- Mock external dependencies

For Frontend (Vitest/Jest):
- Test component rendering
- Test user interactions
- Test API service calls
- Test form validation
- Test routing

Always:
- Write clear test names that describe what is tested
- Test both success and failure cases
- Aim for high code coverage
- Report test results clearly
- Suggest fixes for failing tests

**When you create or modify any test file, ALWAYS use the write_file() tool to save it into backend/tests/ or src/tests/.
After writing tests, ALWAYS run them using run_backend_tests() or run_command('npm run test') and include the output in your final report.**
""",
            tools=[
                read_file,
                write_file,
                list_files,
                run_backend_tests,
                run_frontend_build,
                run_command
            ]
        )
    
    def execute(self, task):
        """Execute testing task"""
        
        prompt = f"""
        Task: {task}
        
        Steps to follow:
        1. Identify what needs to be tested (backend API, frontend component, integration)
        2. Check if tests already exist
        3. Write comprehensive tests covering:
           - Happy path scenarios
           - Edge cases
           - Error handling
           - Input validation
        4. Run the tests and report results
        5. If tests fail, analyze why and suggest fixes
        
        Execute testing now and provide a detailed report.
        """
        
        return self.agent(prompt)