# AIS-TUKE AI Agents

Autonomous AI agents for developing the Academic Information System using Strands framework with local LLMs via Ollama.

## 🏗️ Architecture

```
ai_agents/
├── main.py                      # Entry point, runs orchestration loop
├── agents/
│   ├── orchestrator_agent.py    # Plans and delegates tasks
│   ├── backend_dev_agent.py     # FastAPI backend development
│   ├── frontend_dev_agent.py    # React/Vite frontend development
│   ├── tester_agent.py          # Testing and QA
│   └── tools/
│       ├── filesystem_tools.py  # Safe file operations
│       ├── git_tools.py         # Version control
│       └── build_tools.py       # Running tests, builds, commands
└── memory/
    └── context_manager.py       # Persistent memory and context
```

## 🤖 Agent Roles

### Orchestrator Agent
- **Role**: Project manager and task delegator
- **Responsibilities**:
  - Creates and maintains development plan
  - Breaks down features into tasks
  - Delegates to specialized agents
  - Tracks overall progress
  - Ensures integration

### Backend Developer Agent
- **Role**: FastAPI backend specialist
- **Expertise**:
  - API endpoint development
  - Database models (SQLAlchemy)
  - Authentication/Authorization
  - Business logic
  - Backend testing

### Frontend Developer Agent
- **Role**: React/TypeScript frontend specialist
- **Expertise**:
  - UI components
  - State management
  - API integration
  - Routing
  - Responsive design

### Tester Agent
- **Role**: Quality assurance specialist
- **Expertise**:
  - Writing unit tests
  - Integration testing
  - Running test suites
  - Bug identification
  - Test coverage analysis

## 🚀 Quick Start

### 1. Install Ollama

Download and install from [ollama.com](https://ollama.com/download)

```bash
# Pull the Mistral model (or any other model)
ollama pull mistral

# Start Ollama server
ollama serve
```

### 2. Setup Project

```bash
# Run setup script
chmod +x setup.sh
./setup.sh

# Or manually:
python3 -m venv .venv
source .venv/bin/activate
cd ai_agents
pip install -r requirements.txt
cp .env.example .env
```

### 3. Configure

Edit `ai_agents/.env`:

```bash
STRANDS_MODEL_PROVIDER=openai
OPENAI_API_KEY=ollama
OPENAI_API_BASE=http://localhost:11434/v1
OPENAI_MODEL=mistral
```

### 4. Run Agents

```bash
# Activate virtual environment
source .venv/bin/activate

# Run agents (will run for 8 hours by default)
python ai_agents/main.py
```

### 5. Run Overnight

```bash
# Run in background with logging
nohup python ai_agents/main.py > agent.log 2>&1 &

# Check progress
tail -f agent.log

# Stop agents
pkill -f "python ai_agents/main.py"
```

## 📂 Project Structure

```
AIS-TUKE/
├── backend/              # Your existing FastAPI backend
├── src/                  # Your existing React frontend
├── ai_agents/            # AI agents code (NEW)
│   ├── agents/           # Agent implementations
│   ├── memory/           # Context and history
│   ├── main.py           # Entry point
│   └── requirements.txt  # Python dependencies
├── workspace/            # AI-generated code (NEW)
│   ├── backend/          # New backend features
│   ├── frontend/         # New frontend components
│   └── tests/            # Generated tests
└── memory/               # Agent memory (NEW)
    ├── plan.md           # Development plan
    ├── context.json      # Current state
    └── history.json      # Iteration history
```

## 🛠️ Available Tools

Agents have access to these tools:

### Filesystem Tools
- `read_file(path)` - Read file contents
- `write_file(path, content)` - Write to file
- `list_files(directory)` - List directory contents
- `create_directory(path)` - Create directories
- `delete_file(path)` - Delete files

### Git Tools
- `git_status()` - Check git status
- `git_diff(file)` - Show changes
- `git_add(files)` - Stage files
- `git_commit(message)` - Commit changes
- `git_log(count)` - View history
- `git_create_branch(name)` - Create branch

### Build Tools
- `run_command(cmd)` - Execute shell commands
- `run_backend_tests()` - Run pytest
- `run_frontend_build()` - Build frontend
- `run_frontend_tests()` - Run Vitest
- `install_dependencies()` - Install packages
- `check_python_syntax(file)` - Syntax check
- `run_linter(path)` - Code quality check

## 💾 Memory System

The memory system tracks:

- **context.json**: Current phase, completed/pending tasks
- **history.json**: All iterations with timestamps
- **plan.md**: Development roadmap
- **error_iteration_N.txt**: Error logs

Access memory programmatically:

```python
from memory.context_manager import ContextManager

cm = ContextManager()
context = cm.load_context()
history = cm.get_recent_history(10)
stats = cm.get_statistics()
```

## ⚙️ Configuration

### Runtime Duration

Edit `main.py`:

```python
# Run for 4 hours instead of 8
end_time = datetime.now() + timedelta(hours=4)
```

### Model Selection

Try different local models:

```bash
# In .env file:
OPENAI_MODEL=mistral       # Fast, good reasoning
OPENAI_MODEL=llama3        # Larger, more capable
OPENAI_MODEL=phi3          # Small, efficient
OPENAI_MODEL=codellama     # Code-specialized
```

### Using Cloud Models (Optional)

For GPT-4 or Claude (costs money):

```bash
# OpenAI GPT-4
STRANDS_MODEL_PROVIDER=openai
OPENAI_API_KEY=sk-your-key
OPENAI_API_BASE=https://api.openai.com/v1
OPENAI_MODEL=gpt-4

# Anthropic Claude
STRANDS_MODEL_PROVIDER=anthropic
ANTHROPIC_API_KEY=sk-ant-your-key
ANTHROPIC_MODEL=claude-3-5-sonnet-20241022
```

## 📊 Monitoring Progress

### Check Status

```python
from memory.context_manager import ContextManager

cm = ContextManager()
cm.print_summary()
```

### View Logs

```bash
# Live tail
tail -f agent.log

# Search for errors
grep -i error agent.log

# Count iterations
grep "Iteration" agent.log | wc -l
```

### Review Generated Code

```bash
# Check what was created
ls -la workspace/

# Review specific files
cat workspace/backend/app/routers/users.py
```

## 🎯 Development Workflow

1. **Orchestrator** reads the plan and current context
2. **Orchestrator** decides next task and delegates to specialist
3. **Specialist** (Backend/Frontend/Tester) executes task
4. **Specialist** returns results to orchestrator
5. **Orchestrator** updates memory and context
6. **Repeat** until goals are met or time limit reached

## 🔒 Safety Features

- File operations restricted to `workspace/`, `backend/`, `src/`
- Dangerous shell commands blocked
- All operations timeout after reasonable duration
- Git commits preserve progress
- Error logging for debugging

## 📝 Example Tasks

The agents can handle:

- ✅ Create FastAPI endpoints with authentication
- ✅ Implement SQLAlchemy database models
- ✅ Build React components and pages
- ✅ Set up routing and navigation
- ✅ Write comprehensive tests
- ✅ Integrate frontend with backend API
- ✅ Add form validation
- ✅ Implement authorization logic
- ✅ Create API documentation
- ✅ Refactor and optimize code

## 🐛 Troubleshooting

### Ollama Connection Failed

```bash
# Check if Ollama is running
curl http://localhost:11434/api/tags

# If not, start it
ollama serve
```

### Model Not Found

```bash
# List available models
ollama list

# Pull missing model
ollama pull mistral
```

### Import Errors

```bash
# Reinstall dependencies
pip install -r ai_agents/requirements.txt --force-reinstall
```

### Agent Stuck in Loop

- Check `memory/context.json` for state
- Review `agent.log` for repeated errors
- Manually update context or clear history
- Restart with modified initial task

## 🚦 Best Practices

1. **Start Small**: Begin with one feature, let agents complete it fully
2. **Monitor Regularly**: Check logs every hour or two
3. **Review Code**: Agents make mistakes - review generated code
4. **Test Often**: Make sure tests pass before moving forward
5. **Commit Progress**: Use git to save working states
6. **Clear Goals**: Give specific, measurable objectives
7. **Iterate**: Improve prompts based on what works

## 📚 Resources

- [Strands Documentation](https://github.com/strands-ai/strands)
- [Ollama Models](https://ollama.com/library)
- [FastAPI Docs](https://fastapi.tiangolo.com/)
- [React Docs](https://react.dev/)

## 🤝 Contributing

The agents are self-improving! They learn from:
- Code patterns in your existing project
- Test results and error messages
- Memory of what worked before
- Tool outputs and build logs

## 📄 License

This AI agent system is part of the AIS-TUKE project.