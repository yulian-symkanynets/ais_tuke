"""
Context Manager - Handles memory and context persistence for AI agents
"""
import json
import os
from datetime import datetime
from pathlib import Path

class ContextManager:
    def __init__(self, memory_dir: str = "memory"):
        self.memory_dir = Path(memory_dir)
        self.memory_dir.mkdir(exist_ok=True)
        
        self.history_file = self.memory_dir / "history.json"
        self.plan_file = self.memory_dir / "plan.md"
        self.context_file = self.memory_dir / "context.json"
        
        # Initialize files if they don't exist
        self._init_files()
    
    def _init_files(self):
        """Initialize memory files if they don't exist"""
        if not self.history_file.exists():
            with open(self.history_file, 'w') as f:
                json.dump({"iterations": []}, f, indent=2)
        
        if not self.plan_file.exists():
            with open(self.plan_file, 'w') as f:
                f.write("# AIS-TUKE Development Plan\n\n")
                f.write("This file will be updated by the orchestrator agent.\n")
        
        if not self.context_file.exists():
            with open(self.context_file, 'w') as f:
                json.dump({
                    "current_phase": "initialization",
                    "completed_tasks": [],
                    "pending_tasks": [],
                    "last_updated": datetime.now().isoformat()
                }, f, indent=2)
    
    def load_context(self) -> dict:
        """Load current context from memory"""
        try:
            with open(self.context_file, 'r') as f:
                return json.load(f)
        except Exception as e:
            print(f"Warning: Could not load context: {e}")
            return {
                "current_phase": "unknown",
                "completed_tasks": [],
                "pending_tasks": []
            }
    
    def save_context(self, context: dict):
        """Save current context to memory"""
        context["last_updated"] = datetime.now().isoformat()
        try:
            with open(self.context_file, 'w') as f:
                json.dump(context, f, indent=2)
        except Exception as e:
            print(f"Error saving context: {e}")
    
    def save_iteration(self, iteration: int, result: dict):
        """Save results from an iteration"""
        try:
            # Load existing history
            with open(self.history_file, 'r') as f:
                history = json.load(f)
            
            # Add new iteration
            iteration_data = {
                "iteration": iteration,
                "timestamp": datetime.now().isoformat(),
                "delegated_to": result.get("delegated_to"),
                "summary": result.get("summary", ""),
                "status": result.get("status", "in_progress")
            }
            
            history["iterations"].append(iteration_data)
            
            # Save updated history
            with open(self.history_file, 'w') as f:
                json.dump(history, f, indent=2)
            
            # Update context
            context = self.load_context()
            if result.get("status") == "complete":
                task_summary = result.get("summary", "Unknown task")
                if task_summary not in context["completed_tasks"]:
                    context["completed_tasks"].append(task_summary)
            self.save_context(context)
            
            print(f"💾 Saved iteration {iteration} to memory")
            
        except Exception as e:
            print(f"Error saving iteration: {e}")
    
    def save_error(self, iteration: int, error: str):
        """Save error information"""
        try:
            error_file = self.memory_dir / f"error_iteration_{iteration}.txt"
            with open(error_file, 'w') as f:
                f.write(f"Error at iteration {iteration}\n")
                f.write(f"Timestamp: {datetime.now().isoformat()}\n\n")
                f.write(error)
            print(f"💾 Saved error log to {error_file}")
        except Exception as e:
            print(f"Error saving error log: {e}")
    
    def get_recent_history(self, count: int = 5) -> list:
        """Get recent iteration history"""
        try:
            with open(self.history_file, 'r') as f:
                history = json.load(f)
            iterations = history.get("iterations", [])
            return iterations[-count:] if len(iterations) > count else iterations
        except Exception as e:
            print(f"Error loading history: {e}")
            return []
    
    def update_plan(self, plan_content: str):
        """Update the development plan"""
        try:
            with open(self.plan_file, 'w') as f:
                f.write(f"# AIS-TUKE Development Plan\n\n")
                f.write(f"Last updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
                f.write(plan_content)
            print(f"💾 Updated development plan")
        except Exception as e:
            print(f"Error updating plan: {e}")
    
    def load_plan(self) -> str:
        """Load the current development plan"""
        try:
            with open(self.plan_file, 'r') as f:
                return f.read()
        except Exception as e:
            print(f"Error loading plan: {e}")
            return "No plan available"
    
    def get_statistics(self) -> dict:
        """Get statistics about the development progress"""
        try:
            with open(self.history_file, 'r') as f:
                history = json.load(f)
            
            iterations = history.get("iterations", [])
            
            # Count by agent
            agent_counts = {}
            for iteration in iterations:
                agent = iteration.get("delegated_to", "unknown")
                agent_counts[agent] = agent_counts.get(agent, 0) + 1
            
            # Get context stats
            context = self.load_context()
            
            return {
                "total_iterations": len(iterations),
                "agent_distribution": agent_counts,
                "completed_tasks": len(context.get("completed_tasks", [])),
                "pending_tasks": len(context.get("pending_tasks", [])),
                "current_phase": context.get("current_phase", "unknown")
            }
        except Exception as e:
            print(f"Error getting statistics: {e}")
            return {}
    
    def print_summary(self):
        """Print a summary of the current state"""
        stats = self.get_statistics()
        context = self.load_context()
        
        print("\n" + "="*60)
        print("📊 Development Progress Summary")
        print("="*60)
        print(f"Total Iterations: {stats.get('total_iterations', 0)}")
        print(f"Current Phase: {stats.get('current_phase', 'unknown')}")
        print(f"Completed Tasks: {stats.get('completed_tasks', 0)}")
        print(f"Pending Tasks: {stats.get('pending_tasks', 0)}")
        print("\nAgent Activity:")
        for agent, count in stats.get('agent_distribution', {}).items():
            print(f"  {agent}: {count} iterations")
        print("="*60 + "\n")